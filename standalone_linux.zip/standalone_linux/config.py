import os


# PATHS
# Set the absolute directories of the folders as variables
#data_dir = os.path.abspath(__file__ + '/../data') + '/'
#info_dir = os.path.abspath(__file__ + '/../info') + '/'
#models_dir = os.path.abspath(__file__ + '/../models') + '/'
custom_dir = os.path.abspath(__file__ + '/../custom') + '/'
export_dir = os.path.abspath(__file__ + '/../export') + '/'
#textures_dir = os.path.abspath(__file__+'/../textures') + '/' ### Not needed for now
save_dir = os.path.abspath(__file__+'/../save') + '/'
screenshot_dir = os.path.abspath(__file__+'/../screenshots') + '/'
scripts_dir = os.path.abspath(__file__+'/../scripts') + '/'
