# screenshots
20180531

This is where the screenshots are stored. For now it is a very basic feature, requires imagemagick in linux installed, doesn't work in windows.

This is optional, low priority feature and I might or might not develop it further.


