# textures
20180927

This is the folder with the textures used in the program. Because the textures are/will be baked in the program (so it can run as stand-alone), these images are here in case anyone wants to use them in their project.
